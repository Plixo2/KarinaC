package org.karina.lang.lsp;

public class ClientSettings {
    public boolean excludeErrorFiles = false;
}
